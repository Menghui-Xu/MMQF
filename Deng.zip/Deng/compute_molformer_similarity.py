import torch
import pandas as pd
import numpy as np
from tqdm import tqdm


def compute_molformer_similarity_matrix(
        feature_path: str,
        drug_csv_path: str,
        output_path: str = "molformer_sim_matrix.csv",
        batch_size: int = 100
):
    """
    读取 MoLFormer 特征和药物列表，计算余弦相似度矩阵

    Args:
        feature_path: MoLFormer 特征文件路径 (.pt)
        drug_csv_path: 药物列表 CSV 路径 (需包含 'smiles' 列)
        output_path: 输出 CSV 路径
        batch_size: 分块计算批次大小 (节省内存)
    """
    print("=" * 60)
    print("MoLFormer 相似度矩阵计算")
    print("=" * 60)

    # 1. 加载特征
    print(f"\n[1/4] 加载 MoLFormer 特征: {feature_path}")
    features = torch.load(feature_path)
    print(f"  特征维度: {features.shape}")

    # 2. 加载药物列表并验证顺序一致性
    print(f"\n[2/4] 加载药物列表: {drug_csv_path}")
    df = pd.read_csv(drug_csv_path)
    smiles_list = df['smiles'].tolist()
    print(f"  药物数量: {len(smiles_list)}")

    # 验证数量一致
    assert len(smiles_list) == features.shape[0], \
        f"药物数量不匹配: CSV有{len(smiles_list)}个, 特征有{features.shape[0]}个"

    # 3. 计算余弦相似度矩阵 (分块计算以节省内存)
    print(f"\n[3/4] 计算余弦相似度矩阵 (batch_size={batch_size})...")

    # L2 归一化
    features_norm = features / features.norm(dim=1, keepdim=True).clamp(min=1e-8)
    n = features_norm.shape[0]

    # 转换为 numpy (便于后续操作)
    features_numpy = features_norm.numpy()

    # 分块计算相似度矩阵
    sim_matrix = np.zeros((n, n), dtype=np.float64)

    for i in tqdm(range(0, n, batch_size), desc="计算相似度"):
        end_i = min(i + batch_size, n)
        batch = features_numpy[i:end_i]  # [batch_size, dim]

        # 计算当前 batch 与所有样本的余弦相似度
        # 由于已经 L2 归一化，点积即为余弦相似度
        batch_sim = np.dot(batch, features_numpy.T)  # [batch_size, n]

        # 确保数值在 [-1, 1] 范围内 (由于浮点误差可能略超出)
        batch_sim = np.clip(batch_sim, -1.0, 1.0)

        sim_matrix[i:end_i, :] = batch_sim

    # 4. 保存为 CSV (高精度格式)
    print(f"\n[4/4] 保存相似度矩阵: {output_path}")

    # 使用科学计数法，保留16位小数
    np.savetxt(
        output_path,
        sim_matrix,
        delimiter=',',
        fmt='%.16e'  # 与示例格式一致: 1.0000000000000000e+00
    )

    print(f"\n完成！矩阵已保存至: {output_path}")
    print(f"矩阵维度: {sim_matrix.shape}")
    print(f"内存占用: {sim_matrix.nbytes / 1024 ** 2:.2f} MB")

    # 打印统计信息
    flat = sim_matrix[~np.eye(n, dtype=bool)]  # 排除对角线
    print(f"\n相似度统计 (排除自相似度):")
    print(f"  最小值: {flat.min():.6f}")
    print(f"  最大值: {flat.max():.6f}")
    print(f"  平均值: {flat.mean():.6f}")
    print(f"  标准差: {flat.std():.6f}")

    return sim_matrix


if __name__ == "__main__":
    # 配置路径
    FEATURE_PATH = "Molformer_smiles_features.pt"  # MoLFormer 特征文件
    DRUG_CSV_PATH = "drug_listxiao.csv"  # 药物列表
    OUTPUT_PATH = "molformer_sim_matrix.csv"  # 输出文件

    # 执行计算
    sim_matrix = compute_molformer_similarity_matrix(
        feature_path=FEATURE_PATH,
        drug_csv_path=DRUG_CSV_PATH,
        output_path=OUTPUT_PATH,
        batch_size=100  # 可根据内存调整
    )
# 特征维度: torch.Size([572, 768])